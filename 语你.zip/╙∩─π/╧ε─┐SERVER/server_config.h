#pragma once
#ifndef SERVER_CONFIG_H
#define SERVER_CONFIG_H

#define	SERV_PORT		50050   //服务器端口号
#define	MAX_USER_NUM	200     //最大用户数目 200 尽量不要更改，对服务器压力会比较大
#define	MAX_FRIEND_NUM	50      //用户支持的最大好友数量 50
#define	CONF_LOW_ID		1000    //最小用户id

#define MAX_USER_SIZE	20      /*用户查询所有在线用户每次返回的用户数目*/

#define MAX_MSG_SIZE	512


#endif
