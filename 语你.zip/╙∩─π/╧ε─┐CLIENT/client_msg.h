//所有需要用到的消息以及结构体的声明
#pragma once

#define SERVER_FORWARD_FLAG (0x1 << 15)//区分是真正的用户发送的聊天消息还是服务器反馈的消息，由msg_type的最高位决定
#define MSG_REG		0x01                /*1.用户注册消息*/
#define MSG_LOGIN	0x02                /*2.用户登录消息*/
#define MSG_FRNDMGT	0x03                /*3.好友管理消息*/
#define MSG_CHAT	0x04                /*4.用户聊天消息*/
#define MSG_LOGOUT	0x05                /*5.退出登录消息*/
#define F_LREG		0x01                //3.1 好友列表请求
#define F_ADD		0x02                //3.2 好友增加
#define	F_DEL		0x03                //3.3 好友删除
#define F_ALST		0x04                //3.4 列出所有用户
#define F_STAT		0x05                //3.5 好友状态查询
#define MAXNAME_LEN			16          /*最大的用户名长度*/
#define MAX_USERPASS_LEN	6           /*最大的用户密码长度*/
#define MAX_ERR_LEN		80
#define LOGIN_OK	1
#define LOGIN_ERR	2
#define USR_ONLINE		1               /*好友的在线状态*/
#define USR_OFFLINE		2
#define OP_ALL_OK	1                   //好友管理全部ok
#define OP_PART_OD	2                   //只操作了一部分
#define OP_ALL_FAIL	3                   //好友管理全部fail
#define SND_OK		1 //服务器中转成功
#define SND_ERR		2 //服务器中转失败



/*通用消息结构体，这是客户端和服务器端交互的消息的统一结构*/
typedef struct msg_header
{
	unsigned short msg_type;            /*消息类型*/
	unsigned short msg_len;             /*消息长度*/
	char msg_data[0];                    /*可变长度的消息内容*/
}MSG_HDR;


/*1.用户注册消息与注册的回复消息*/
typedef	struct reg_msgdata//注册消息
{
	char r_name[MAXNAME_LEN];               //昵称
	char r_passwd[MAX_USERPASS_LEN];        //密码
}REG_MSG;

typedef struct reg_msg_resp                 //注册后服务器回复的消息结构体
{
	int re_id;                               /*将uid返回给客户端，-1表示出错*/
	char re_reason[0];                       /*出错的原因，这个东西实际上是一个指针而非数组*/
}REG_RESP;


/*2.用户登录消息与登录的回复消息*/
typedef struct login_msg                    //登录消息
{
	int lg_id;
	char lg_pass[MAX_USERPASS_LEN];
}LIG_MSG;

typedef struct login_resp                   //登陆回复消息结构体，由服务器给客户端发送
{
	int lg_stat;                            /*登录状态 1表示ok  2表示出错*/
	char lg_name[MAXNAME_LEN];              //返回用户名
	char lg_reason[0];                      //返回错误原因
}LIG_RESP;


/*3.好友管理信息*/
typedef struct frnd_op                      /*对好友进行操作，使用msg_type进行操作*/
{
	int f_id;                                /*用户本身*/

	int f_fids[0];                           /*表示需要操作的用户id数组*/
}FRND_OP;

//好友状态结构体
typedef struct frnd_stat
{
	char fs_name[MAXNAME_LEN];
	int fs_id;
	int fs_stat;
}FRND_ST;

typedef struct frnd_op_resp                 //对好友操作的回复
{
	short fre_stat;                          //好友的在线状态
	short fre_num;                           /*成功操作的数目*/
	FRND_ST fre_ok_frnd[0];                  /*好友的基本信息*/
}FRND_RESP;

/*4.聊天信息*/
typedef struct chat_msg
{
	int ch_sid;                             /*发送者id*/
	int ch_rid;                             /*接收者id*/
	char ch_msg[0];                         /*需要发送的文本信息*/
}CHAT_MSG;

//服务器转发聊天信息后的反馈
typedef struct chat_resp
{
	int c_stat;
	char c_reason[0];
}CHAT_RESP;

/*5.用户登出消息*/
typedef struct logout_msg
{
	int lg_id;
	char lg_pass[MAX_USERPASS_LEN];
}LOUT_MSG;



