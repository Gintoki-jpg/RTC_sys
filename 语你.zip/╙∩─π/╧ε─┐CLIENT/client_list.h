#pragma once
#ifndef CLIENT_LIST_H
#define CLIENT_LIST_H

#define LIST_POSITION ((void *) 0x0)
#define LIST_HEAD_INIT(name)  { &(name), &(name)}                                       //链表头部初始化
#define LIST_HEAD(name) struct list_head name = LIST_HEAD_INIT(name)                    //定义头部
#define INIT_LIST_HEAD(ptr) \
	do{(ptr)->next=(ptr);(ptr)->prev=(ptr); \
} while(0)                                                                              //初始化头部
#define list_for_each(pos, head) for(pos = (head)->next; pos != (head); pos = pos->next)//初始化pos指针等于head类 正向遍历链表
#define list_for_each_prev(pos, head) \
	for(pos = (head)->prev; pos != (head); pos = pos->prev)                             //逆向遍历链表，每次遍历都得到一个好友结构
#define offsetof(t, m) ((size_t)(&((t *)0) -> m))                                       //计算偏移量
#define container_of(ptr, type, member) (((char *)(ptr)) - offsetof(type, member))
#define list_entry(ptr, type, member) container_of(ptr, type, member)                   //从遍历得到的list_head中得到client_friend


struct list_head //双向循环列表的前向指针和后向指针
{
	struct list_head  *next, *prev;
};
void __list_add(struct list_head *node, struct list_head *prev, struct list_head *next);//节点插入
void __list_del(struct list_head *prev, struct list_head *next);//节点删除
void list_add(struct list_head *node, struct list_head *head);/*将新节点插入作为第一个节点，是__list_add的包裹函数*/
void list_del(struct list_head *entry);
void list_del_init(struct list_head *entry);
void list_add_tail(struct list_head *node, struct list_head *head);/*将新节点插入到头结点之前即链表的尾部，是__list_add的包裹函数*/
int list_empty(const struct list_head *head);//判断链表是否为空

#endif
