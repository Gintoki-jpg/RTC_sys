//客户端配置文件
#pragma once
#ifndef CLIENT_CONFIG_H
#define CLIENT_CONFIG_H

#define SERVER_PORT		50050
#define MAX_MSG_SIZE	512

#endif // !CLIENT_CONFIG_H

